package datakeeper;

import javax.swing.tree.DefaultMutableTreeNode;


public class Kapsula extends DefaultMutableTreeNode {
		
		public Entity ent;
		public Kapsula(Entity n) {
			ent=n;
		}

	}

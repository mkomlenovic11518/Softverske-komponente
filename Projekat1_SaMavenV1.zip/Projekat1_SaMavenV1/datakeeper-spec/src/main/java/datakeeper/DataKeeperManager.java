package datakeeper;


public class DataKeeperManager {
	
private static DataKeeper dataKeeper;
	
	public static void registerDataKeeper(DataKeeper dk) {
		dataKeeper = dk;		
	}
	
	public static DataKeeper getDataKeeper(String fileName) {
		dataKeeper.setFileName(fileName);
		return dataKeeper;
	}

}

package datakeeper;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;

import javax.swing.JOptionPane;


public class Konfiguracija {
	private int id_entiteta;
	private String naziv_entiteta;
	private int redni_broj_primerka;
	
	private static Konfiguracija instance=null;
	public static Konfiguracija Instance() {
		if(instance==null) {
			instance=new Konfiguracija();
		}
		
		return instance;
	}
	
	
	ArrayList<String> lista;
	
	private Konfiguracija(){
		
		lista = new ArrayList<String>();
	}
	
	public void createKonfiguracija() {
		try {
			File konf = new File("Img\\Konfiguracija.txt");
			
		}catch(Exception e) {
			JOptionPane.showMessageDialog(null, e);
			e.printStackTrace();
		}
	}
	
	public int najveciEntityID() {
		FileReader fr;
		BufferedReader bf;
		int brojac = 0;
		try {
			fr = new FileReader("Img\\Konfiguracija.txt");
			bf = new BufferedReader(fr);
			String s = bf.readLine();
			while(s!=null) {
				String[] tokens = s.split(",");
				int pom = Integer.parseInt(tokens[0]);
				if(pom>=brojac) {
					brojac = pom;
				}
				
				s = bf.readLine();
			
			}
			bf.close();
			fr.close();
		
		}catch(IOException e) {
			JOptionPane.showMessageDialog(null, e);
			e.printStackTrace();
		}
		
		return  brojac;
	}
	
	public int getID() {
		FileReader fr;
		BufferedReader bf;
		int brojac = 0;
		lista.clear();
		try {
			fr = new FileReader("Img\\Konfiguracija.txt");
			bf = new BufferedReader(fr);
			String s = bf.readLine();
			while(s!=null) {
				String[] tokens = s.split(",");
				
				int pom = Integer.parseInt(tokens[0]);
				if(pom==-1) {
					brojac=Integer.parseInt(tokens[2])+1;
					s="-1,"+tokens[1]+","+Integer.toString(brojac);
				}
				lista.add(s);
				s = bf.readLine();
			
			}
			bf.close();
			fr.close();
			// upis u fajl
			BufferedWriter outputStream = null;
			String fileNameWrite="Img\\Konfiguracija.txt";
	    	try {
	            outputStream = new BufferedWriter(new FileWriter(fileNameWrite,false));
	            for(int i=0;i<lista.size();i++) {
	            	outputStream.write(lista.get(i));
	            	outputStream.newLine();
	            }
	            outputStream.close();
	            
	        } catch (Exception e) {
	           JOptionPane.showConfirmDialog(null, e);
	        }
			
			
			return brojac;
		
		}catch(IOException e) {
			JOptionPane.showMessageDialog(null, e);
			e.printStackTrace();
		}
		
		return  brojac;
	}
	
	public int isSlobodanUnos() {
		
			FileReader fr;
			BufferedReader bf;
			int brojac = -1;
			try {
				fr = new FileReader("Img\\Konfiguracija.txt");
				bf = new BufferedReader(fr);
				String s = bf.readLine();
				while(s!=null) {
					String[] tokens = s.split(",");
					
					int pom = Integer.parseInt(tokens[0]);
					if(pom==-2) {
						brojac=Integer.parseInt(tokens[2]);
						break;
					}
					
					s = bf.readLine();
				
				}
				bf.close();
				fr.close();
			}catch(Exception e) {
				JOptionPane.showMessageDialog(null, e);
			}
				return brojac;
	}
	
	public int brojPrimeraka(int ID_entiteta) {
		FileReader fr;
		BufferedReader bf;
		int broj = -1;
		try {
			fr = new FileReader("Img\\Konfiguracija.txt");
			bf = new BufferedReader(fr);
			String s = bf.readLine();
			while(s!=null) {
				String[] tokens = s.split(",");
				if(ID_entiteta==Integer.parseInt(tokens[0])) {
					broj = Integer.parseInt(tokens[2]);
				}
				
				
				s = bf.readLine();
			
			}
			bf.close();
			fr.close();
		
		}catch(IOException e) {
			JOptionPane.showMessageDialog(null, e);
			e.printStackTrace();
		}
		
		return broj;
	}
	
	public String imeEntiteta(int ID_entiteta) {
		FileReader fr;
		BufferedReader bf;
		String ime = "";
		try {
			fr = new FileReader("Img\\Konfiguracija.txt");
			bf = new BufferedReader(fr);
			String s = bf.readLine();
			while(s!=null) {
				String[] tokens = s.split(",");
				if(ID_entiteta==Integer.parseInt(tokens[0])) {
					ime = tokens[1];
				}
				
				
				s = bf.readLine();
			
			}
			bf.close();
			fr.close();
		
		}catch(IOException e) {
			JOptionPane.showMessageDialog(null, e);
			e.printStackTrace();
		}
		
		return ime;
	}
	
	public String idEntiteta(String imeentit) {
		FileReader fr;
		BufferedReader bf;
		String id = "";
		try {
			fr = new FileReader("Img\\Konfiguracija.txt");
			bf = new BufferedReader(fr);
			String s = bf.readLine();
			while(s!=null) {
				String[] tokens = s.split(",");
				if(imeentit.matches(tokens[1])) {
					id = tokens[0];
				}
				
				
				s = bf.readLine();
			
			}
			bf.close();
			fr.close();
		
		}catch(IOException e) {
			JOptionPane.showMessageDialog(null, e);
			e.printStackTrace();
		}
		
		return id;
	}
	
	public void kreirajEntitet(int ID_entiteta,String naziv){
		BufferedWriter outputStream = null;
		String fileNameWrite="Img\\Konfiguracija.txt";
		try {
			
	    	
			outputStream = new BufferedWriter(new FileWriter(fileNameWrite,true));
	            
	           outputStream.write(Integer.toString(ID_entiteta)+","+naziv+",1");
	            	
	           
	            outputStream.close();
			
		
		}catch(IOException e) {
			System.out.println("An error occurred.");
			e.printStackTrace();
		}
	}
	
	
}

package datakeeper;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;
import java.util.Enumeration;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;

public class PretragaDlg  extends JDialog{
private static PretragaDlg instance=null;
	
	public static PretragaDlg Instance(JFrame r, JTree t) {
		if(instance==null) {
			instance= new PretragaDlg(r,t);
		}
	return instance;
	}
	
	public ArrayList<String> al;
	public JFrame mf;
	public JTree tree;
	public JTextField imeEntiteta;
	//public JTextField idEntiteta;
	//public JTextField opisInstanceEntiteta;
	public JTextField vrednostInstanceEntiteta;
	
	public JButton ok; 
	public JButton cancel;
	
private PretragaDlg(JFrame r, JTree t) {
		
		super(r,"Pretraga podataka o entitetu",true);
		mf=r;
		tree=t;
		
		imeEntiteta = new JTextField();
		imeEntiteta.setPreferredSize(new Dimension(180,20));
		al=new ArrayList<String>();
		
		Box w=Box.createHorizontalBox();
		Box c=Box.createHorizontalBox();
		Box d=Box.createHorizontalBox();
		Box e=Box.createHorizontalBox();
		Box f=Box.createHorizontalBox();
		Box a=Box.createVerticalBox();
	
		Box b=Box.createHorizontalBox();
		b.setPreferredSize(new Dimension(255,20));
		JLabel k1= new JLabel("Naziv:        ");
		k1.setAlignmentX(LEFT_ALIGNMENT);
		b.add(k1);
		b.add(Box.createHorizontalGlue());
		imeEntiteta.setAlignmentX(RIGHT_ALIGNMENT);
		b.add(imeEntiteta);
		
		
		
		
		
		/*JLabel k2= new JLabel("IdEnt:         ");
		k2.setAlignmentX(LEFT_ALIGNMENT);
		c.add(k2);
		c.add(Box.createHorizontalGlue());
		idEntiteta= new JTextField();
		c.add(idEntiteta);
		c.add(Box.createGlue());
		c.setAlignmentX(CENTER_ALIGNMENT);*/
		
		
		/*JLabel k3= new JLabel("Opis:          ");
		k3.setAlignmentX(LEFT_ALIGNMENT);
		d.add(k3);
		d.add(Box.createHorizontalGlue());
		opisInstanceEntiteta=new JTextField();
		d.add(opisInstanceEntiteta);
		//d.add(Box.createGlue());*/
		
		JLabel k4= new JLabel("Vrednost: ");
		k4.setAlignmentX(LEFT_ALIGNMENT);
		e.add(k4);
		e.add(Box.createHorizontalGlue());
		vrednostInstanceEntiteta=new JTextField();
		e.add(vrednostInstanceEntiteta);
		e.add(Box.createGlue());
		
			
			imeEntiteta.setText("");
			//idEntiteta.setText("");
			//opisInstanceEntiteta.setText("");
			vrednostInstanceEntiteta.setText("");
			
		f.add(Box.createHorizontalGlue());
		
		
		a.add(b);
		
		a.add(c);
		a.add(d);
		a.add(e);
		
		JPanel p1 = new JPanel();
		p1.add(a);
		this.add(p1,BorderLayout.WEST);
		this.setSize(350,230);
		
		JPanel p2 = new JPanel();
		ok = new JButton("Ok");
		cancel = new JButton("Cancel");
		p2.add(ok);
		p2.add(cancel);
		this.add(p2, BorderLayout.SOUTH);
		
		
		
		
		this.ok.addActionListener(new ActionListener() { 
			public void actionPerformed(ActionEvent ev) {
				
				al.clear();
				DefaultTreeModel dm=(DefaultTreeModel)tree.getModel();
				Kapsula ent=(Kapsula) dm.getRoot();
				
				Enumeration<TreeNode> e = ent.preorderEnumeration();
				while (e.hasMoreElements()) {
			    Kapsula dmtn=((Kapsula)e.nextElement());
			    Kapsula dmtn_parent=(Kapsula)dmtn.getParent();
			    
			      
			       if ( !(dmtn_parent==null) ) {
			    	   Entity no = dmtn.ent;
				       Entity no_parent = dmtn_parent.ent;
			    	   String row= no_parent.getID() + ","+ no.getID()+","+no.getTip()+","+no.getIme()+","+no.getID_ent()+","+no.getOpis()+","+no.getVrednost();
			       	 
			    	if(!imeEntiteta.getText().isEmpty() && !vrednostInstanceEntiteta.getText().isEmpty()) {
				       		if(no.getIme().contains(imeEntiteta.getText()) && no.getVrednost().contains(vrednostInstanceEntiteta.getText()) ){
				       			al.add(row);
				       		}
			       	  }
			    	else if(imeEntiteta.getText().isEmpty() && !vrednostInstanceEntiteta.getText().isEmpty()) {
					       		if(no.getVrednost().contains(vrednostInstanceEntiteta.getText())  ){
					       			al.add(row);
					       		}
				       	  }
			    	else if(!imeEntiteta.getText().isEmpty() && vrednostInstanceEntiteta.getText().isEmpty()) {
					       		if(no.getIme().contains(imeEntiteta.getText())   ){
					       			al.add(row);
					       		}
				       	  }
			    	else if(imeEntiteta.getText().isEmpty() && vrednostInstanceEntiteta.getText().isEmpty()) {
					       		
				       	  }
			    	   
			       }
			    }
				
				setVisible(false);
			 
				
			}
			
			
		});
		
		
		
		cancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ev) {
				setVisible(false);
				
				return;
			}
			
		});
		
	
		
		this.setLocationRelativeTo(mf);
		 //this.setVisible(true);
		 
		 this.setLocation(500, 300);
		 this.pack();
		
	}
}

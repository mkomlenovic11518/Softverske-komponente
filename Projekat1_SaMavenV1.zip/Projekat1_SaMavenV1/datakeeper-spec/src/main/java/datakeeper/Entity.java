package datakeeper;

import java.util.ArrayList;
import java.util.Enumeration;

import javax.swing.tree.DefaultMutableTreeNode;





public class Entity  {
	
	//private ArrayList<Entity> Parametri = new ArrayList<Entity>(); 

	public Entity() {}
	
	
	public Entity(int p, String i,String o, int ide, int iex, String tp,String vr) {
		 ime=i;
		 opis=o;
		 id=ide;
		 id_ent=iex;
		 tip=tp;
		 vrednost=vr;
		 parent=p;
		
	}
	private String ime;
	private String opis;
	private int id;
	private int id_ent;
	private String tip;
	private String vrednost;
	private int parent;
	
	public void setIme(String s) {
		ime=s;
	}
	
	public void setVrednost(String s) {
		vrednost=s;
	}
	
	
	public void setOpis(String o) {
		opis=o;
	}
	public void setID(int g) {
		id=g;
	}
	public void setID_ent(int g) {
		id_ent=g;
	}
	public void setTip(String s) {
		tip=s;
	}
	
	public void setParent(int s) {
		parent=s;
	}
	public String getIme() {
		return ime;
	}
	public int getID() {
		return id;
	}
	public int getID_ent() {
		return id_ent;
	}
	public String getOpis() {
		return opis;
	}
	public String getVrednost() {
		return vrednost;
	}
	public String getTip() {
		return tip;
	}
	
	public int getParent() {
		return parent;
	}

	

	
	

}

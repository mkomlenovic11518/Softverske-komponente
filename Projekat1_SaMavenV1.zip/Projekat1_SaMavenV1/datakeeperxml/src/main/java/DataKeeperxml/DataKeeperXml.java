package datakeeperXml;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.StringWriter;
import java.util.ArrayList;


import javax.swing.JOptionPane;
import javax.xml.parsers.*;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import datakeeper.DataKeeper;
import datakeeper.DataKeeperManager;


public class DataKeeperXml extends DataKeeper{
	public static ArrayList<String>repo =new ArrayList<String>();
	public int brojacListe=0;
	public String redListe="";
	
	
	
	static {
		DataKeeperManager.registerDataKeeper(new DataKeeperXml());
	}
    
	public DataKeeperXml(){
    	super();
    }
	
	
	private static void visitChildNodes(NodeList nList)
	   {
		
		 
	      for (int temp = 0; temp < nList.getLength(); temp++)
	      {
	         Node node = nList.item(temp);
	         if (node.getNodeType() == Node.ELEMENT_NODE)
	         {
	            System.out.println("Node Name = " + node.getNodeName() + "; Value = " + node.getTextContent());
	            repo.add(node.getNodeName()+","+ node.getTextContent());
	        	
	            
	            if (node.hasChildNodes()) {
	                  //rekurzija
	                  visitChildNodes(node.getChildNodes());
	               }
	        
	         }
	      }
	   }
	
	/**
	 * Funkcija koja cita XML fajl, pretvara xml format u format
	 * parent,id_node,type_node,name_entity,id_entity,description,value
	 * pakuje ArrayList pripremljenim podacima
	 */
	@Override 
	public ArrayList<String> readAndParseData(String path){
		
		String fileName=path;
		ArrayList<String> ali=new ArrayList<String>();
		
		
		try {
			DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
			DocumentBuilder builder = factory.newDocumentBuilder();
			Document document = builder.parse(new File( fileName ));
			Node objects=document.getDocumentElement();
			objects.normalize();
			document.getDocumentElement().normalize();
			
			Element root = document.getDocumentElement();
		    System.out.println(root.getNodeName());
		    NodeList cvorovi=root.getChildNodes();
		   
		    repo.clear();
		    visitChildNodes(cvorovi);
			
			brojacListe=0;
			redListe="";
			int prvi=1;
		    
			ali.clear();
			for(int i=0; i<repo.size();i++) {
				String p=repo.get(i);
				String[] t=p.split(",");
				if(t[0].matches("parent")) {
					if(prvi==1) {
						prvi=0;
					}else {
						ali.add(redListe.substring(0,redListe.length()-1));
					}
					redListe="";
					
				}
				if(t[0].matches("parent") || t[0].matches("id")|| t[0].matches("ime")||t[0].matches("opis")||t[0].matches("vrednost")||t[0].matches("id_ent")||t[0].matches("tip")) {
					redListe=redListe+t[1]+",";
				}
			}
			ali.add(redListe.substring(0,redListe.length()-1));

		}catch(Exception e) {
			
		}
		
	  return ali;	
	 }
	
	
	/**
	 * Funkcija koja format
	 * parent,id_node,type_node,name_entity,id_entity,description,value
	 * pakuje u XML format i upisuje na yadatu putanju
	 */
	
	@Override
	 public void parseAndWriteData(ArrayList<String> al, String path) {
		xmlUpisi(al,path);
	}
	
	
	private static Node createElements(Document doc, String name, String value) {
        Element node = doc.createElement(name);
        node.appendChild(doc.createTextNode(value));
        return node;
    }

	
	public void xmlUpisi(ArrayList<String> ali,String path){
		
		String fileName=path;
		
		try {
			
			
			
			DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
	        DocumentBuilder dBuilder=dbFactory.newDocumentBuilder();
	        
	        Document doc = dBuilder.newDocument();
	        
			String s=ali.get(0);
			String[] t=s.split(",");
			
			String parent=t[0];
			String id=t[1];
			String tip=t[2];
			String ime=t[3];
			String id_ent=t[4];
			String opis=t[5];
			String vrednost=t[6];
			
			
            Element rootElement =
                doc.createElement(ime+id);
            doc.appendChild(rootElement);
            
            rootElement.appendChild(createElements(doc, "parent",parent));
            rootElement.appendChild(createElements(doc, "id",id));
            rootElement.appendChild(createElements(doc, "tip",tip));
            rootElement.appendChild(createElements(doc, "ime",ime));
            rootElement.appendChild(createElements(doc, "id_ent",id_ent));
            rootElement.appendChild(createElements(doc, "opis",opis));
            rootElement.appendChild(createElements(doc, "vrednost",vrednost));
			
			
            rootElement=recursivePop(ali.get(0), ali, doc, rootElement);
		
			
			
			 
            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();
            //da bi se pravilo nazubljivanje
            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            DOMSource source = new DOMSource(doc);

           
            StreamResult file = new StreamResult(new File(fileName));

            //upis podataka
           
            transformer.transform(source, file);
			
		} catch (Exception e) {
	           JOptionPane.showConfirmDialog(null, e);
	        	 
	     }
	}

	
	public Element   recursivePop(String s, ArrayList<String> a,Document builder, Element root) {
		
		String[] t=s.split(",");
		
		String parent=t[0];
		String id=t[1];
		String tip=t[2];
		String ime=t[3];
		String id_ent=t[4];
		String opis=t[5];
		String vrednost=t[6];

		for(int i=0;i<a.size();i++) {
			String ss=a.get(i);
			String[] tt=ss.split(",");
			
			String parent1=tt[0];
			String id1=tt[1];
			String tip1=tt[2];
			String ime1=tt[3];
			String id_ent1=tt[4];
			String opis1=tt[5];
			String vrednost1=tt[6];
			
			// ako je id parent datog reda, onda se ugnjezdava taj red
			if(id.matches(parent1)) {
				System.out.println("NUMBER " + ime1+id1);
				
				
				 Element newElement =
						 builder.createElement(ime+id);
				 root.appendChild(newElement);
				
			            
			            newElement.appendChild(createElements(builder, "parent",parent1));
			            newElement.appendChild(createElements(builder, "id",id1));
			            newElement.appendChild(createElements(builder, "tip",tip1));
			            newElement.appendChild(createElements(builder, "ime",ime1));
			            newElement.appendChild(createElements(builder, "id_ent",id_ent1));
			            newElement.appendChild(createElements(builder, "opis",opis1));
			            newElement.appendChild(createElements(builder, "vrednost",vrednost1));
						
				
				
				
			            root=recursivePop( ss,  a, builder,newElement);
				
			}
		}
		return root;
	}
		
	

}

package datakeeper;


import java.awt.FileDialog;
import java.util.ArrayList;
import java.util.Enumeration;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JTree;
import javax.swing.SwingUtilities;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.MutableTreeNode;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;




/**
 * Apstraktna klasa koja predstavlja specifikaciju komponente
 * @author Marko Komlenovic, oktobar-novembar 2020
 *
 */
public abstract class DataKeeper {
	/**
	 * Atribut koji reprezentuje tip datoteke u kojoj 
	 * se cuvaju podaci, moze biti JSON, XML ili CUSTOM
	 */
	protected String fileType;
	/**
	 * javni konstruktor
	 */
	public DataKeeper() {
		
	}
	
	/**
	 * funkcija koja postavlja vrednost fileName
	 * @param fileName ovaj parametar oznacava tip datoteke
	 */
	public void setFileName(String ft) {
		this.fileType = ft;
		
	}
	
	/**
	 * Funkcija cita fajl koji se nalazi na putanji path
	 * pretvara JSON,XML ili CUSTOM format u niz stringova
	 * od kojih svaki predstavlja jedan cvor koji ce se predstaviti u stablu JTree
	 * format svakog stringa je sledeci: parent,id_node,type_node,name_entity,id_entity,description,value
	 * 
	 * @param path
	 * @return
	 */
	
	abstract public ArrayList<String> readAndParseData(String path);
	
	/**
	 * Funkcija koja input u vidu ArrayList iz JTree,pretvara u
	 *  JSON,XML ili CUSTOM format i upisuje u fajl na zadatoj putanji
	 * @param al
	 * @param path
	 */
	
	abstract public void parseAndWriteData(ArrayList<String> al, String path);
	
	/**
	 * Funkcija koja sortira podatke istog tipa Entity, one koji imaju
	 * isti id_entity i isti naziv
	 * @param al ArrayList svih podataka
	 * @param desc opadajuce/rastuce, desc=1 opadajuce, desc=0 rastuce
	 */
	
	 public void sort(ArrayList<String> al, int desc) {}
	 
	/**
	 * Funkcija koja iz ArrayList uklanja Entity sa id_entity i name
	 * @param al
	 * @param id
	 * @param name
	 */
	
	 public void deleteEntity(ArrayList<String> al, int id,String name) {}
	 
	/**
	 * Funkcija koja ulazni parametar koji je ArrayList u formatu podataka
	 *  parent,id_node,type_node,name_entity,id_entity,description,value 
	 *  pretvara u DefaultTreeModel koji moze da se pridruzi JTree i prikaze podatke
	 *  Node-ovi JTree stabla su klasa Kapsula koja sadrzi klasu Entity. Entity je apstrakcija koja moye da predstavlja 
	 *  bilo koji podatak i moguce je formirati stablo proizvoljne sadrzine
	 * @param al
	 * @return
	 */
	
	public DefaultTreeModel createTreeModel(ArrayList<String> al) {
		Entity con = new Entity ();
		con.setIme("root");
		Kapsula tn=new Kapsula(con);
		tn.setUserObject("root");
		
		Kapsula roditelj=tn;
	    DefaultTreeModel dm33 = new DefaultTreeModel(tn);
	    for (int i=0;i<al.size();i++) {
	    	String[] tok = al.get(i).split(",");
	    	/*format koji se ocekuje*/
	    	/* parent,id_node,type_node,name_entity,id_entity,description,value*/
	    	int parent = Integer.parseInt(tok[0]);
	    	int id_node=Integer.parseInt(tok[1]);
	    	String type_node=tok[2];
	    	String name_ent=tok[3];
	    	int id_ent=Integer.parseInt(tok[4]);
	    	String des=tok[5];
	    	String value = tok[6];
	    	Entity en = new Entity(parent,name_ent,des,id_node, id_ent, type_node,value);
	    	//kreiranje DefaultMutableTreeNode koji sadrzi Entity
	    	Kapsula tnxx=new Kapsula(en);
	    	tnxx.setUserObject(en.getIme());
	    	try {
	    	if(parent==0) {
	    		dm33.insertNodeInto((Kapsula)tnxx, tn, tn.getChildCount());
	    		roditelj=tnxx;
	    	}
	    	else if(parent==(roditelj.ent.getID())){
	    			    		
	    		dm33.insertNodeInto((Kapsula)tnxx, roditelj, roditelj.getChildCount());
	    		roditelj=tnxx;
	    	}
	    	else if (parent !=(roditelj.ent.getID())) {
	    		
	    		Kapsula k=(Kapsula) dm33.getRoot();
	    		
	    		
	    		Enumeration<TreeNode> e = k.depthFirstEnumeration();
	    	    while (e.hasMoreElements()) {
	    	    Kapsula dmtn=((Kapsula)e.nextElement());
	    	       Entity no = dmtn.ent;
	    	        if (no.getID()==parent) {
	    	        	TreePath p=new TreePath(dmtn.getPath());
	    	        	roditelj = (Kapsula)p.getLastPathComponent();
	    	        	
	    	        	dm33.insertNodeInto((Kapsula)tnxx, roditelj, roditelj.getChildCount());
	    	        	break;
	    	        }
	    	    }
	    		
	    	}
	    	}catch (Exception e) {
	    		JOptionPane.showMessageDialog(null,e);
	    	}
	    	
	    }
    return dm33;
	}
	
	/**
	 * Funkcija koja cita DefaultTreeModel iz JTRee i prebacuje ga 
	 * u format stringa koji odgovara custom modelu. U zavisnosti koja implemenatcija se koristi
	 * ova lista stringova se kasnije pretvara u odgovarajuci format
	 * @param dm
	 * @return vraca listu stringova
	 */
	
	public ArrayList<String> readTreeModel(DefaultTreeModel dm){
		ArrayList<String> al=new ArrayList<String>();
		Kapsula ent=(Kapsula) dm.getRoot();
		
		Enumeration<TreeNode> e = ent.preorderEnumeration();
		while (e.hasMoreElements()) {
	    Kapsula dmtn=((Kapsula)e.nextElement());
	    Kapsula dmtn_parent=(Kapsula)dmtn.getParent();
	    
	      
	       if ( !(dmtn_parent==null) ) {
	    	   Entity no = dmtn.ent;
		       Entity no_parent = dmtn_parent.ent;
	    	   String row= no_parent.getID() + ","+ no.getID()+","+no.getTip()+","+no.getIme()+","+no.getID_ent()+","+no.getOpis()+","+no.getVrednost();
	       	 al.add(row);
	       }
	    }
		

	    return al;
	}
	
/**
 * Funkcija koja ucitava fajl u nekom od formata (json, xml, custom txt) 
 * tako sto otvara dijalog za izbor fajla
 * poziva funkciju readAndParseData odgovarajuce implementacije
 * i pretvara ocitanoi sadrzaj u DefaultTreeModel koji se ucitava u JTree
 * @param m
 * @return
 */
	
public DefaultTreeModel ucitaj(JFrame m) {
		
    	// otvaranje novog fajla sa konfiguracijom
    	// koristi se open dijalog
    	FileDialog fd=new FileDialog(m,"Izaberi datoteku", FileDialog.LOAD);
    	fd.setDirectory("Img\\");
    	fd.setFile("*.txt;*.js;*.xml");
    	fd.setLocation(150, 200);
    	fd.setVisible(true);
    	String fileName=fd.getDirectory()+fd.getFile();
    	if(fd.getFile()==null) {// ako je cancel onda getFile vraca null
    		
    		return null;
    	}
    	// poziv  funkcija za ucitavanje fajla
    	// i popunjavanje JTtree modela
    	
		ArrayList<String> al=readAndParseData(fileName);
		DefaultTreeModel dm44=  createTreeModel(al);
		
    	return dm44;
}

/**
 * Funkcija koja snima fajl u nekom od formata (json, xml, custom txt) 
 * tako sto otvara dijalog za izbor fajla
 * poziva funkciju readTreeModel koja cita sadrzaj JTree
 * i pomocu parseAndWriteData odgovarajuce implementacije snima u odgovarajucem formatu
 * @param m
 * @param tree
 */

public void snimi(JFrame m, JTree tree) {
	
	StringBuffer sb = new StringBuffer();
	sb.append((char)13);//CR
	sb.append((char)10);//LF
	String crlfTerminator = sb.toString();
	
	
	// otvaranje novog fajla sa konfiguracijom
	// koristi se open dijalog
	FileDialog fd=new FileDialog(m,"Izaberi datoteku", FileDialog.SAVE);
	fd.setDirectory("C:\\Users\\HP\\Desktop\\DSW\\");
	fd.setFile("*.txt;*.json;*.xml");
	fd.setLocation(150, 200);;
	fd.setVisible(true);
	String fileName=fd.getDirectory()+fd.getFile();
	if(fd.getFile()==null) {// ako je cancel onda getFile vraca null
		
		return;
	}
	
	// poziv  funkcija za snimanje fajla
	// i citanje JTtree modela
	
	ArrayList<String> al= readTreeModel((DefaultTreeModel)tree.getModel());
	parseAndWriteData(al, fileName);
	
	JOptionPane.showMessageDialog(null, "Uspesno upisan fajl "+ fileName);
	
}

/**
 * Funkcija koja u JTRee dodaje novi DefaultMutableTreeNode-klasa Kapsula
 * koja sadrzi objekat klase Entity. Otvara se dijalog EntityDlg.
 * @param f
 * @param t
 */

public void add(JFrame f, JTree t) {
	EntityDlg.Instance(f,t,1).pripremi(f,t,1);
	EntityDlg.Instance(f,t,1).setVisible(true);
	SwingUtilities.updateComponentTreeUI(t);
	
}

/**
 * Funcija koja vraca podatke o cvorovima koji sadrze
 * sadryaj koji je naveden u pretrazi. Moguce je pretrazivati po imenu 
 * entiteta i vrednosti cvora. Otvara se dijalog PretragaDlg
 * @param f
 * @param t
 * @return
 */

public ArrayList<String> find(JFrame f, JTree t) {
	PretragaDlg.Instance(f,t).setVisible(true);
	return PretragaDlg.Instance(f,t).al;
	
}

/**
 * Funkcija koja omogucava prommenu sadrzaja
 * odredjenog cvora u JTree. Otvara se dijalog EntityDlg.
 * @param f
 * @param t
 */

public void edit(JFrame f, JTree t) {
	EntityDlg.Instance(f,t,0).pripremi(f,t,0);
	EntityDlg.Instance(f,t,0).setVisible(true);
	
	SwingUtilities.updateComponentTreeUI(t);
	
}
	
/**
 * Funkcija koja brise izabrani cvor u stablu i sve cvorove ispod njega.	
 * @param drvo
 * @return
 */
public DefaultTreeModel delete(JTree drvo) {
		
		MutableTreeNode nNode;
		
		DefaultTreeModel dm=(DefaultTreeModel)drvo.getModel();
		DefaultTreeModel dm1=dm;
		 //pitamo da li se sigurno zeli brisanje
		 int opt=JOptionPane.showConfirmDialog(null,"Da li sigurno zelite da brisete? Brisu se svi potomci", "Izbor",JOptionPane.YES_NO_OPTION);
		if (opt==JOptionPane.NO_OPTION) {
			 return dm;
		 }
    	  
    	  
    	 
    	  try {
    		  
    					    	  
		    	  TreePath[] paths = drvo.getSelectionPaths();
	                if (paths != null) {
	                    for (TreePath path : paths) {
	                        DefaultMutableTreeNode node = (DefaultMutableTreeNode) path.getLastPathComponent();
	                        if (node.getParent() != null) {
	                        	dm.removeNodeFromParent(node);
	                        }
	                    }
	                }

		    	  
		    	  
		    	  
		    	  
		    	  return dm;
		    	
		    	  
    	  }catch(Exception e) {
    		  
    		  JOptionPane.showMessageDialog(null, e);
    		  return dm1;
    		  
    	  }
 
	}

/**
 * Funkcija koja kreira novu konfiguraciju
 * odnosno prazno JTree
 * @return
 */
	public DefaultTreeModel novi() {
		
		//Inicijalno popunjavanje JTree
		Entity con = new Entity ();
		con.setIme("root");
		Kapsula tn=new Kapsula(con);
		tn.setUserObject("root");
		
		
	    DefaultTreeModel dm33 = new DefaultTreeModel(tn);
	    return dm33;
	}
	

}

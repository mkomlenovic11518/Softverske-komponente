package datakeeperCustom;


import datakeeper.DataKeeper;
import datakeeper.DataKeeperManager;


import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;

import javax.swing.JOptionPane;

public class DataKeeperCustom extends DataKeeper{
	
	static {
		DataKeeperManager.registerDataKeeper(new DataKeeperCustom());
	}
    
	public DataKeeperCustom(){
    	super();
    }
    
	@Override 
	public ArrayList<String> readAndParseData(String path){
		
		String fileName=path;
		ArrayList<String>al =new ArrayList<String>();
		try {
            BufferedReader inputStream = new BufferedReader(new FileReader(fileName));
            String s;
	    	// prvo ucitavamo ime konfiguracije
	    	s=inputStream.readLine();
	    	String header="parent,id_node,type_node,name_entity,id_entity,description,value";
	    	if(!s.matches(header)) {
	    		JOptionPane.showConfirmDialog(null, "Nije dobar format fajla");
	    		return null;
	    	}
	    	while((s=inputStream.readLine())!=null) {
	    		al.add(s);
	    	
	    	}
	    	inputStream.close();
		} catch (Exception e) {
	           JOptionPane.showConfirmDialog(null, e);
	        	 
	     }
		
		 
		 return al;
	 }
	@Override
	 public void parseAndWriteData(ArrayList<String> al, String path) {
		String fileName=path;
		
		try {
			BufferedWriter  outputStream = new BufferedWriter(new FileWriter(fileName));
            String header="parent,id_node,type_node,name_entity,id_entity,description,value";
            outputStream.write(header + "\r\n");
	    	for(int i=0;i<al.size();i++) {
	    		outputStream.write(al.get(i)+ "\r\n");
	    	
	    	}
	    	outputStream.close();
		} catch (Exception e) {
	           JOptionPane.showConfirmDialog(null, e);
	        	 
	     }
	}
	
}

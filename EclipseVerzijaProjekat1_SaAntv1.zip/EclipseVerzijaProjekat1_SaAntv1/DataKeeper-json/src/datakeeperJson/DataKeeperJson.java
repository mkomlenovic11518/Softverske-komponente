package datakeeperJson;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.Reader;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonNumber;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.json.JsonReader;
import javax.json.JsonString;
import javax.json.JsonStructure;
import javax.json.JsonValue;
import javax.json.JsonWriter;
import javax.swing.JOptionPane;



import datakeeper.DataKeeper;
import datakeeper.DataKeeperManager;
import datakeeper.Entity;



public class DataKeeperJson extends DataKeeper{
	
	
	public static ArrayList<String>repo =new ArrayList<String>();
	public int brojacListe=0;
	public String redListe="";
	
	
	
	static {
		DataKeeperManager.registerDataKeeper(new DataKeeperJson());
	}
    
	public DataKeeperJson(){
    	super();
    }
	
	
	public static void navigateTree(JsonValue tree, String key) {
		 String s="";  
		if (key != null) {
		      System.out.print("Key " + key + ":");
		       s="Key " + key + ":";
			
		}
		   switch(tree.getValueType()) {
		      case OBJECT:
		         System.out.println("OBJECT");
		         repo.add(s+"OBJECT");
		         JsonObject object = (JsonObject) tree;
		        
		         for (String name : object.keySet())
		            navigateTree(object.get(name), name);
		         break;
		      case ARRAY:
		         System.out.println("ARRAY");
		         JsonArray array = (JsonArray) tree;
		         for (JsonValue val : array)
		            navigateTree(val, null);
		         break;
		      case STRING:
		         JsonString st = (JsonString) tree;
		        
		         System.out.println("STRING " + st.getString());
		         repo.add(s+ st.getString());
		         break;
		      case NUMBER:
		         JsonNumber num = (JsonNumber) tree;
		         
		         System.out.println("NUMBER " + num.toString());
		         repo.add(s+num.toString());
		         break;
		      case TRUE:
		      case FALSE:
		      case NULL:
		         System.out.println(tree.getValueType().toString());
		         break;
		   }
		  
		}
	
	/**
	 * Funkcija koja cita JSON fajl, pretvara json format u format
	 * parent,id_node,type_node,name_entity,id_entity,description,value
	 * pakuje ArrayList pripremljenim podacima
	 */
	@Override 
	public ArrayList<String> readAndParseData(String path){
		
		String fileName=path;
		ArrayList<String> ali=new ArrayList<String>();
		try {
			JsonReader reader = Json.createReader(new FileReader(path));
			JsonStructure jsonst = reader.read();
			JsonObject model= (JsonObject)jsonst;
			
			repo.clear();
			brojacListe=0;
			redListe="";
			int prvi=1;
		    navigateTree(model,null);
			ali.clear();
			for(int i=0; i<repo.size();i++) {
				String p=repo.get(i);
				String[] t=p.split(":");
				if(t[0].matches("OBJECT")) {
					redListe="";
				}
				else if(t[1].matches("OBJECT")) {
					if(prvi==1) {
						prvi=0;
					}else {
						ali.add(redListe.substring(0,redListe.length()-1));
					}
					redListe="";
					
				}
				else {
					redListe=redListe+t[1]+",";
				}
			}
			ali.add(redListe.substring(0,redListe.length()-1));

		}catch(Exception e) {
			
		}
	  return ali;	
	 }
	
	
	
	
	@Override
	 public void parseAndWriteData(ArrayList<String> al, String path) {
		jsonUpisi(al,path);
	}
	
	public JsonObjectBuilder   recursivePop(String s, ArrayList<String> a,JsonObjectBuilder builder) {
		
		String[] t=s.split(",");
		
		String parent=t[0];
		String id=t[1];
		String tip=t[2];
		String ime=t[3];
		String id_ent=t[4];
		String opis=t[5];
		String vrednost=t[6];

		for(int i=0;i<a.size();i++) {
			String ss=a.get(i);
			String[] tt=ss.split(",");
			
			String parent1=tt[0];
			String id1=tt[1];
			String tip1=tt[2];
			String ime1=tt[3];
			String id_ent1=tt[4];
			String opis1=tt[5];
			String vrednost1=tt[6];
			
			if(id.matches(parent1)) {
				System.out.println("NUMBER " + ime1+id1);
				JsonObjectBuilder builder1=Json.createObjectBuilder();
				builder1.add("parent",parent1);
				builder1.add("id",id1);
				builder1.add("tip",tip1);
				builder1.add("ime",ime1);
				builder1.add("id_ent",id_ent1);
				builder1.add("opis",opis1);
				builder1.add("vrednost",vrednost1);
				
				builder1=recursivePop( ss,  a, builder1);
				builder.add(ime1+id1,builder1);
			}
		}
		return builder;
	}
		
		
		
	public void jsonUpisi(ArrayList<String> ali,String path){
			
		String fileName=path;
		
		try {
			
			
			
			JsonObjectBuilder builder = Json.createObjectBuilder();
			String s=ali.get(0);
			String[] t=s.split(",");
			
			String parent=t[0];
			String id=t[1];
			String tip=t[2];
			String ime=t[3];
			String id_ent=t[4];
			String opis=t[5];
			String vrednost=t[6];
			
			JsonObjectBuilder builder1=Json.createObjectBuilder();
			builder1.add("parent",parent);
			builder1.add("id",id);
			builder1.add("tip",tip);
			builder1.add("ime",ime);
			builder1.add("id_ent",id_ent);
			builder1.add("opis",opis);
			builder1.add("vrednost",vrednost);	
			
		
			
			builder1=recursivePop(ali.get(0), ali, builder1);
			builder.add(ime+id,builder1);
			JsonObject model=builder.build();
			
			StringWriter stWriter = new StringWriter();
			JsonWriter jsonWriter = Json.createWriter(stWriter);
			jsonWriter.writeObject(model);
			jsonWriter.close();

			String jsonData = stWriter.toString();
		
			// ovaj string treba upisati u fajl na putanju koja jezadata
			BufferedWriter  outputStream = new BufferedWriter(new FileWriter(fileName));
	        
	        outputStream.write(jsonData);
	    	
	    	outputStream.close();
			
		} catch (Exception e) {
	           JOptionPane.showConfirmDialog(null, e);
	        	 
	     }
	}

}

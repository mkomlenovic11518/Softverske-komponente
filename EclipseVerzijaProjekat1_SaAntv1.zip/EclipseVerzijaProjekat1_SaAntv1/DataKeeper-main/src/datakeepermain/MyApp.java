package datakeepermain;

import java.awt.Dimension;
import java.awt.Toolkit;



public class MyApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MainFrame mf=MainFrame.Instance();
		// odredjivanje dimenzija ekrana
		Toolkit tk= Toolkit.getDefaultToolkit();
		Dimension D=tk.getScreenSize();
		int w=D.width;
		int h=D.height;
		int w1=w/2;
		int h1=h/2;
		
		mf.setSize(w1, h1);
		int w2=w/2-w1/2;
		int h2=h/2-h1/2;
		mf.setLocation(w2, h2);
		
		
		mf.setVisible(true);
	}

}

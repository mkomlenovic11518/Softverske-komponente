package datakeepermain;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FileDialog;
import java.awt.FlowLayout;
import java.awt.KeyboardFocusManager;
import java.awt.Menu;
import java.awt.MenuBar;
import java.awt.MenuItem;
import java.awt.Toolkit;
import java.awt.Window;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.DataFlavor;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.Transferable;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.WindowEvent;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.StringWriter;
import java.sql.DriverManager;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

/*import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.json.JsonWriter;*/



import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JToolBar;
import javax.swing.JTree;
import javax.swing.ScrollPaneConstants;
import javax.swing.SwingUtilities;
import javax.swing.border.BevelBorder;
import javax.swing.border.Border;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.MutableTreeNode;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import datakeeper.Entity;
import datakeeper.Kapsula;

import datakeeper.DataKeeperManager;
import datakeeper.DataKeeper;


import javax.xml.parsers.*;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;



public class MainFrame extends JFrame implements ActionListener  {
	
	// atribut instance i metoda Instance za Singleton
	private static MainFrame instance=null;
	public static MainFrame Instance() {
		if(instance==null) {
			instance=new MainFrame();
		}
		return instance;
	}
	
	
	
	
	public JTree tree;
	public String fn;
	
	public JTextField prikaz;
	public JTextArea prikaz2;
	
	
	
	public MenuBar mb;
	public Menu f1;
	public Menu f2;
	public Menu f3;
	public Menu ex;
	public Menu ab;
	
	public JPanel pane; //za toolbar
	public JPanel pane5; //za stablo
	public JPanel pane6; //panel za split
	public JPanel pane7; //panel za split
	public JPanel pane8; //za datum i vreme
	
	public JButton button0;//dugme za novo stablo
	public JButton button1;
	public JButton button2;//dugme za dodavanje cvora
	public JButton button3;
	public JButton button4;// dugme za izbacivanje cvora
	public JButton button5;//dugme za zamenu dva cvora
	public JButton button6;//dugme za zamenu dva cvora
	
	
	
	
	
	JToolBar bar;
	
	JTextField tekst; // za datum i vreme
	JTextArea putanja;//za ispis detalja o cvoru, koliko cvorova iza itd..
	
    public String put=null;
	
   
	
	private MainFrame() {        
		super(); 
	
		//run time ucitavanje implementacione klase
		// za interfejs
		
		try {	
			//Class.forName("datakeeperCustom.DataKeeperCustom");
			Class.forName("datakeeperJson.DataKeeperJson");
			//Class.forName("datakeeperXml.DataKeeperXml");
		}
		catch (Exception e) {
			e.printStackTrace();
		}
		
		//fn="datakeeperCustom.DataKeeperCustom";
		fn="datakeeperJson.DataKeeperJson";
		//fn="datakeeperXml.DataKeeperXml";
		Dimension temp_dim=new Dimension(160,30);
			
	
		
		pane8=new JPanel();
		
		setSize(1100, 1000);  // Dimenzije su inicijalno (0, 0)   
		setTitle("Softverske Komponente, I projekat"); 
		
	
		 

		mb = new MenuBar();
		this.setMenuBar(mb);
		f1=new Menu("File");
		mb.add( f1);
		f1.addActionListener(this);	
	    f1.add(new MenuItem("mNew"));
		f1.add(new MenuItem("mOpen"));
		f1.addSeparator();	// ovo je separator linija
	    f1.add(new MenuItem("mAdd"));
	    f1.add(new MenuItem("mDelete"));
	    f1.add(new MenuItem("mEdit"));
	    f1.addSeparator();	// ovo je separator linija
	    f1.add(new MenuItem("mSave"));
	    
	   
	    f1.add(new MenuItem("Exit"));
	    
		// deo za toolbar
		ImageIcon image0 = new ImageIcon("Img/new.png");
		button0 = new JButton(image0);
		button0.setToolTipText("Kreiranje nove konfiguracije");
		ImageIcon image1 = new ImageIcon("Img/Open_file.png");
		button1 = new JButton(image1);
		button1.setToolTipText("Otvaranje snimljene konfiguracije");
		ImageIcon image2 = new ImageIcon("Img/add.png");
			
	    button2 = new JButton(image2);
	    button2.setToolTipText("Dodavanje novog cvora");
		ImageIcon image3 = new ImageIcon("Img/save.png");
		button3 = new JButton(image3);
		button3.setToolTipText("Snimanje konfiguracije");
		ImageIcon image4 = new ImageIcon("Img/min24x24.jpg");
		button4 = new JButton(image4);
		button4.setToolTipText("Brisanje cvora");
		ImageIcon image5 = new ImageIcon("Img/replacement.png");
		button5 = new JButton(image5);
		button5.setToolTipText("Izmena cvora");
		ImageIcon image6 = new ImageIcon("Img/help.png");
		button6 = new JButton(image6);
		button6.setToolTipText("Pretraga");
		
		
		
		bar = new JToolBar();
		bar.add(button0);
	    bar.add(button1);
	    bar.add(button2);
	    bar.add(button4);
	    bar.add(button5);
	    bar.add(button3);
	    bar.add(button6);
	    
	   
	    pane = new JPanel(new BorderLayout());
	    
	    // pane 5 je panel za stablo
	    pane5=new JPanel(new BorderLayout());
	    
	    pane5.setBorder(BorderFactory.createBevelBorder(BevelBorder.RAISED));
	    pane6=new JPanel(new BorderLayout());
	    pane7=new JPanel(new BorderLayout());
	        
	   
	    FlowLayout Fl=new FlowLayout(FlowLayout.RIGHT);
	    pane8.setLayout(Fl);// ovde se prikazuju datum i vreme 
	    tekst=new JTextField();
	    pane8.add(tekst);
	    
	    pane.add("North", bar);
	    //Inicijalno popunjavanje JTree
	    DefaultMutableTreeNode con = new DefaultMutableTreeNode("root");
	   
	    //kreiranje inicijlane pozadinske strukture podataka stabla
	   
	    tree =new JTree(con);
	    tree.setRootVisible(true);
	    DefaultTreeCellRenderer renderer = 
	            new DefaultTreeCellRenderer();
	        
	    tree.setCellRenderer(renderer);
	    
	    DefaultTreeModel dm1 = new DefaultTreeModel(con);
	    tree.setModel(dm1);
	    
	    // dodavanje eventa na JTree kako bi se prepoznalo
	    // koji je cvor selektovan
	    tree.addTreeSelectionListener(new TreeSelectionListener() {
	    	@Override
	    	public void valueChanged(TreeSelectionEvent e) {
	    		Kapsula selectedNode= 
	    				(Kapsula)tree.getLastSelectedPathComponent();
	    		if((selectedNode==null)) return;
	    		if(!(selectedNode.getParent()==null)) {
	    		prikaz2.setText("Naziv:"+ selectedNode.ent.getIme() + "\r\n"+
	    				"ID_Entiteta:"+selectedNode.ent.getID_ent() + "\r\n"+
	    				        "ID:"+selectedNode.ent.getID() + "\r\n");
	    		putanja.setText("Opis:"+ selectedNode.ent.getOpis() + "\r\n"+
	    				"Tip:"+ selectedNode.ent.getTip() + "\r\n"+
	    				"Vrednost:"+ selectedNode.ent.getVrednost() + "\r\n"+
	    				"Parent:" + selectedNode.ent.getParent());
	    		}
	    		
	    	}
	    });
	    // popunjavanje inicijalnih podataka
	   
	    Dimension dima=new Dimension();
	    dima.height=this.getHeight();
	    dima.width=250;
	    pane5.setPreferredSize(new Dimension(300,500));
	    
	    tree.setPreferredSize(dima);
	    pane5.add("West",tree);
	    
	    JScrollPane Pane1=new JScrollPane(pane5, ScrollPaneConstants.VERTICAL_SCROLLBAR_ALWAYS,  ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		Pane1.setPreferredSize(dima); 
	    BorderLayout bord1=new BorderLayout();
	    //ovaj panel sluzi za prikaz podataka iz cvora stabla
	    JSplitPane split=new JSplitPane(JSplitPane.VERTICAL_SPLIT,pane6,pane7);
	        
	    Dimension dim=new Dimension();
	    dim.height=this.getHeight();
	    dim.width=100;
	        
	    Dimension dim1=new Dimension();
	    dim1.height=230;
	    dim1.width=300;
	    prikaz=new JTextField();
	    prikaz2=new JTextArea();
	    Dimension temp_prikaz=new Dimension(550,320);
		prikaz.setPreferredSize(temp_prikaz);
		prikaz2.setPreferredSize(temp_prikaz);
	        
	    
	    pane6.setBackground(Color.GRAY);
	    pane6.setPreferredSize(dim1);
	    pane6.add(prikaz,BorderLayout.CENTER);
	    pane7.setBackground(Color.GRAY);
	    pane7.add(prikaz2,BorderLayout.CENTER);
	  
	    split.setPreferredSize(dim1);
	    split.setDividerLocation(60);
	    pane7.setPreferredSize(dim1);
	    this.add(Pane1,BorderLayout.WEST);
	    this.add(pane,BorderLayout.NORTH);
	    this.add(split, BorderLayout.CENTER);
	    this.add(pane8, BorderLayout.SOUTH);
	    Date d=new Date();
	    tekst.setText(d.toString());
	 
	    // ACTION LISTENER ZA DUGME0 NOVE KONFIGURACIJE
	    button0.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent ae){
	    		DataKeeper dk = DataKeeperManager.getDataKeeper(fn);
	    		DefaultTreeModel dm= dk.novi();
	    		
	        	tree.setModel(dm);
	        	SwingUtilities.updateComponentTreeUI(tree);	
	    		
	    	}
	    		
	    });
	    
	    // ACTION LISTENER ZA DUGME1 OPEN KONFIGURACIJE
	    button1.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent ae){
	    		DataKeeper dk = DataKeeperManager.getDataKeeper(fn);
	    		
	    		DefaultTreeModel dm44=dk.ucitaj(MainFrame.Instance());
	    		
	        	tree.setModel(dm44);
	        	SwingUtilities.updateComponentTreeUI(tree);	
	    		
	    	}
	    		
	    });
	   
	    // ACTION LISTENER ZA DUGME2, DODAVANJE CVORA
	    button2.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent ae){
	    		
	    		DataKeeper dk = DataKeeperManager.getDataKeeper(fn);
	    		
	    		dk.add((JFrame)MainFrame.Instance(),tree);
	    	}	
	    });
	    
	    // ACTION LISTENER ZA DUGME3, snimanje
	    button3.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent ae){
	    		
	    		DataKeeper dk = DataKeeperManager.getDataKeeper(fn);
	    		
	    		dk.snimi(MainFrame.Instance(),tree);
	    	}	
	    });
	    
	    
	    // ACTION LISTENER ZA DUGME6, pretraga
	    button6.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent ae){
	    		
	    		DataKeeper dk = DataKeeperManager.getDataKeeper(fn);
	    		
	    		ArrayList<String> test= dk.find(MainFrame.Instance(),tree);
	    		String rez="";
	    		for (int i=0;i<test.size();i++) {
	    			rez=rez+test.get(i)+"\n\r";
	    			
	    		}
	    		putanja.setText(rez);
	    		
	    	}	
	    });
	    
	  
	   
	    
	    
	    //////////////////////////////////////////////////////////  
	    // ACTION LISTENER ZA DUGME4, za brisanje cvorova ispod putanje
	    button4.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent ae){
	    		DataKeeper dk = DataKeeperManager.getDataKeeper(fn);
	    		DefaultTreeModel dm= dk.delete(tree);
	    		
	        	tree.setModel(dm);
	        	SwingUtilities.updateComponentTreeUI(tree);	
	    	}
	    });
	    
	    
	    // za menjanje cvora
	    button5.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent ae){
	    		DataKeeper dk = DataKeeperManager.getDataKeeper(fn);
				
				dk.edit((JFrame)MainFrame.Instance(),tree);
	    	
	    	};
	    	
	    });
	    

putanja = new JTextArea();
putanja.setPreferredSize(new Dimension(410,180));
putanja.setText("ovde pisu informacije vezane za cvor");
prikaz2.setText("II prikaz");
prikaz.setText("INFORMACIJE VEZANE ZA CVOR");
//pane8.add(putanja);
Border border = BorderFactory.createLineBorder(Color.gray);
putanja.setBorder(border);
prikaz2.setBorder(border);
pane7.add(putanja,BorderLayout.SOUTH);

////////////////////////////////////////////////////////// 
//kraj konstruktora    

}
	
	
	

	public void exit() {
		WindowEvent we;
        we = new WindowEvent(this, WindowEvent.WINDOW_CLOSING);

       this.dispatchEvent(we);
	}
	
	
	public void actionPerformed(ActionEvent e)
	  {
		    String str = e.getActionCommand();		//koja je opcija pritisnuta
		 
		    
		    if(str=="Exit") {
		    	exit();

		    }else if (str=="mOpen") {
		    	
		    	DataKeeper dk = DataKeeperManager.getDataKeeper(fn);
	    		
	    		DefaultTreeModel dm44=dk.ucitaj(MainFrame.Instance());
	    		
	        	tree.setModel(dm44);
	        	SwingUtilities.updateComponentTreeUI(tree);	
		    
		  }else if (str=="mNew") {
		    	
			  DataKeeper dk = DataKeeperManager.getDataKeeper(fn);
	    		DefaultTreeModel dm= dk.novi();;
	    		
	        	tree.setModel(dm);
	        	SwingUtilities.updateComponentTreeUI(tree);	
		    
		  }else if (str=="mAdd") {
		    	
			  	DataKeeper dk = DataKeeperManager.getDataKeeper(fn);
				
				dk.add((JFrame)MainFrame.Instance(),tree);
		    
		  }else if (str=="mDelete") {
		    	
			  	DataKeeper dk = DataKeeperManager.getDataKeeper(fn);
	    		DefaultTreeModel dm= dk.delete(tree);
	    		
	        	tree.setModel(dm);
	        	SwingUtilities.updateComponentTreeUI(tree);	
		    
		  }else if (str=="mEdit") {
		    	
			  	DataKeeper dk = DataKeeperManager.getDataKeeper(fn);
				
				dk.edit((JFrame)MainFrame.Instance(),tree);
		    
		  }else if (str=="mSave") {
		    	
			  	DataKeeper dk = DataKeeperManager.getDataKeeper(fn);
	    		
	    		dk.snimi(MainFrame.Instance(),tree);
	    		
	        	
		    
		  }	    
	  }

	

}
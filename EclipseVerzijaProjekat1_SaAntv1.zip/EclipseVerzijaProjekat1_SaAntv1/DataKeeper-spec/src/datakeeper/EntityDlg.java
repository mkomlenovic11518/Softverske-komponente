package datakeeper;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.SwingUtilities;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;

/**
 * Klasa koja otvara dijalog i omogucava 
 * editovanje ili kreiranje novog Entiteta odnosno
 * cvora u JTree stablu
 * @author Marko Komlenovic
 *
 */

public class EntityDlg extends JDialog{
private static EntityDlg instance=null;
	
	public static EntityDlg Instance(JFrame r, JTree t, int ne) {
		if(instance==null) {
			instance= new EntityDlg(r,t,ne);
		}
	return instance;
	}
	
	
	
	public JTextField imeEntiteta;
	public JTextField idEntiteta;
	public JTextField opisInstanceEntiteta;
	public JTextField vrednostInstanceEntiteta;
	public JTextField idInstanceEntiteta;
	public JButton ok; 
	public JButton cancel;
	public JCheckBox checkBox1; 
	
	public JFrame mf;
	public JTree tree;
	int newOrEdit; // ako se kreira novi cvor onda je 1, ako se edituje onda 0
	
private EntityDlg(JFrame r, JTree t, int NewOrEdit) {
		
		super(r,"Unos podataka o entitetu",true);
		mf=r;
		tree=t;
		newOrEdit=NewOrEdit;
		imeEntiteta = new JTextField();
		imeEntiteta.setPreferredSize(new Dimension(180,20));
		idInstanceEntiteta= new JTextField();
		idInstanceEntiteta.setPreferredSize(new Dimension(180,20));
		
		Box w=Box.createHorizontalBox();
		Box c=Box.createHorizontalBox();
		Box d=Box.createHorizontalBox();
		Box e=Box.createHorizontalBox();
		Box f=Box.createHorizontalBox();
		Box a=Box.createVerticalBox();
	
		Box b=Box.createHorizontalBox();
		b.setPreferredSize(new Dimension(255,20));
		JLabel k1= new JLabel("Naziv:        ");
		k1.setAlignmentX(LEFT_ALIGNMENT);
		b.add(k1);
		b.add(Box.createHorizontalGlue());
		imeEntiteta.setAlignmentX(RIGHT_ALIGNMENT);
		b.add(imeEntiteta);
		
		
		w.setPreferredSize(new Dimension(255,20));
		JLabel k1w= new JLabel("ID:          ");
		k1w.setAlignmentX(LEFT_ALIGNMENT);
		w.add(k1w);
		w.add(Box.createHorizontalGlue());
		idInstanceEntiteta.setAlignmentX(RIGHT_ALIGNMENT);
		w.add(idInstanceEntiteta);
		
		
		
		JLabel k2= new JLabel("IdEnt:         ");
		k2.setAlignmentX(LEFT_ALIGNMENT);
		c.add(k2);
		c.add(Box.createHorizontalGlue());
		idEntiteta= new JTextField();
		c.add(idEntiteta);
		c.add(Box.createGlue());
		c.setAlignmentX(CENTER_ALIGNMENT);
		
		
		JLabel k3= new JLabel("Opis:          ");
		k3.setAlignmentX(LEFT_ALIGNMENT);
		d.add(k3);
		d.add(Box.createHorizontalGlue());
		opisInstanceEntiteta=new JTextField();
		d.add(opisInstanceEntiteta);
		//d.add(Box.createGlue());
		
		JLabel k4= new JLabel("Vrednost: ");
		k4.setAlignmentX(LEFT_ALIGNMENT);
		e.add(k4);
		e.add(Box.createHorizontalGlue());
		vrednostInstanceEntiteta=new JTextField();
		e.add(vrednostInstanceEntiteta);
		e.add(Box.createGlue());
		checkBox1= new JCheckBox("Slobodan unos ID: "); 
		
		if(Konfiguracija.Instance().isSlobodanUnos()==0) {
			checkBox1.setSelected(false);
			checkBox1.enable(false);
		}
		
		
		
		// ako je editovanje, puni se sadrzaj
		if(newOrEdit==0){
			TreePath path = tree.getSelectionPath();
		   	Kapsula node;
			DefaultTreeModel dm=(DefaultTreeModel)tree.getModel();
			node = (Kapsula)path.getLastPathComponent();
			imeEntiteta.setText(node.ent.getIme());
			idInstanceEntiteta.setText(Integer.toString(node.ent.getID()));
			idEntiteta.setText(Integer.toString(node.ent.getID_ent()));
			opisInstanceEntiteta.setText(node.ent.getOpis());
			vrednostInstanceEntiteta.setText(node.ent.getVrednost());
		}
		else{
			idInstanceEntiteta.setText("");;
			imeEntiteta.setText("");
			idEntiteta.setText("");
			opisInstanceEntiteta.setText("");
			vrednostInstanceEntiteta.setText("");
			if(checkBox1.isSelected()) {
	   			   
	   			   
	   		 }
			else {
				//int br=Konfiguracija.Instance().getID();
	   			//idInstanceEntiteta.setText(Integer.toString(br));
	   			idInstanceEntiteta.disable();
				
			}
			
			
		}
		
		
		f.add(Box.createHorizontalGlue());
		
		f.add(checkBox1);
		f.add(Box.createGlue());
		
		a.add(b);
		a.add(w);
		a.add(c);
		a.add(d);
		a.add(e);
		a.add(f);
		JPanel p1 = new JPanel();
		p1.add(a);
		this.add(p1,BorderLayout.WEST);
		this.setSize(350,230);
		
		JPanel p2 = new JPanel();
		ok = new JButton("Ok");
		cancel = new JButton("Cancel");
		p2.add(ok);
		p2.add(cancel);
		this.add(p2, BorderLayout.SOUTH);
		
		
		
		
		this.ok.addActionListener(new ActionListener() { 
			public void actionPerformed(ActionEvent ev) {
				
				TreePath path = tree.getSelectionPath();
			   	Kapsula node;
				DefaultTreeModel dm=(DefaultTreeModel)tree.getModel();
				try {
			   		node = (Kapsula)path.getLastPathComponent();
				   	   
			   		if(newOrEdit==0){
			   			node.ent.setIme(imeEntiteta.getText());
			   			node.ent.setID_ent(Integer.parseInt(idEntiteta.getText()));
			   			node.ent.setOpis(opisInstanceEntiteta.getText());
			   			node.ent.setID(Integer.parseInt(idInstanceEntiteta.getText()));
			   			node.ent.setVrednost(vrednostInstanceEntiteta.getText());
			   			node.setUserObject(imeEntiteta.getText());
			   			
			   		}
			   		else {
			   		   // kreiranje novog cvora
			   		   // prvo provera da li postoji dati identitet po ID_ent
			   		   
			   		   int parent=node.ent.getID();
				   	   //int id_node=FUnkcija iz klase koja vraca id za dati entitet
				   	   int id_node=Integer.parseInt(idInstanceEntiteta.getText());
				   	   if(Konfiguracija.Instance().brojPrimeraka(Integer.parseInt(idEntiteta.getText()))!=-1) {
				   		imeEntiteta.setText(Konfiguracija.Instance().imeEntiteta(Integer.parseInt(idEntiteta.getText())));
				   	   }
				   	   else {
				   		JOptionPane.showMessageDialog(null, "Novi entitet, bice unet u bazu sa adekvatnim ID entiteta");
				   				int inovi=Konfiguracija.Instance().najveciEntityID()+1;
				   				idEntiteta.setText(Integer.toString(inovi));
				   				Konfiguracija.Instance().kreirajEntitet(inovi, imeEntiteta.getText());
				   				
				   	   }
				   	   String type="0";
				   	   String name=imeEntiteta.getText();
				   	   int id_ent=Integer.parseInt(idEntiteta.getText());
				   	   String opis=opisInstanceEntiteta.getText();
				   	   String vrednost=vrednostInstanceEntiteta.getText();
				   	   Entity en = new Entity(parent,name,opis,id_node, id_ent, type,vrednost);
				   	   Kapsula p=new Kapsula(en);
				   	   p.setUserObject(en.getIme());
				   	   dm.insertNodeInto(p, node, node.getChildCount());
			   		}
				   	tree.setModel(dm);
					   
					    	 				    	 
					setVisible(false);
					    	  
				   		
				}
				catch (Exception ec){
					JOptionPane.showMessageDialog(null, ec);
					
					ec.printStackTrace();
				}
				
				
				
			}
			
			
		});
		
		// Focus listener
		
		 FocusListener tfieldListener = new FocusListener()
	    {
	        @Override
	        public void focusGained(FocusEvent fe)
	        {
	        }

	        @Override
	        public void focusLost(FocusEvent fe)
	        {
	            System.out.println("I am LOST");
	            String n = imeEntiteta.getText().trim();
	            String id=Konfiguracija.Instance().idEntiteta(n);
	            idEntiteta.setText(id);
	            
	        }
	    };
	    imeEntiteta.addFocusListener(tfieldListener);
		
		cancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent ev) {
				setVisible(false);
				//mf.setVisible(true);
				return;
			}
			
		});
		
		checkBox1.addItemListener(new ItemListener() {    
            public void itemStateChanged(ItemEvent e) {                 
                 if(checkBox1.isSelected()) {
                	 idInstanceEntiteta.enable();
                 }
                 else idInstanceEntiteta.disable();
            }    
         });    
		
		this.setLocationRelativeTo(mf);
		 //this.setVisible(true);
		 
		 this.setLocation(500, 300);
		 this.pack();
		
	}

	public void pripremi(JFrame r, JTree t, int n) {
		// ako je editovanje, puni se sadrzaj
				newOrEdit=n;
				tree=t;
				if(newOrEdit==0){
				TreePath path = tree.getSelectionPath();
				   	Kapsula node;
					DefaultTreeModel dm=(DefaultTreeModel)tree.getModel();
					node = (Kapsula)path.getLastPathComponent();
					imeEntiteta.setText(node.ent.getIme());
					idEntiteta.setText(Integer.toString(node.ent.getID_ent()));
					opisInstanceEntiteta.setText(node.ent.getOpis());
					vrednostInstanceEntiteta.setText(node.ent.getVrednost());
					idInstanceEntiteta.setText(Integer.toString(node.ent.getID()));
				}
				else{
						
					imeEntiteta.setText("");
					idEntiteta.setText("");
					opisInstanceEntiteta.setText("");
					vrednostInstanceEntiteta.setText("");
					idInstanceEntiteta.setText("");;
					if(checkBox1.isSelected()) {
			   			   
			   			   
			   		 }
					else {
						int br=Konfiguracija.Instance().getID();
			   			idInstanceEntiteta.setText(Integer.toString(br));
			   			idInstanceEntiteta.disable();
						
					}
					
					
				}
	}

}

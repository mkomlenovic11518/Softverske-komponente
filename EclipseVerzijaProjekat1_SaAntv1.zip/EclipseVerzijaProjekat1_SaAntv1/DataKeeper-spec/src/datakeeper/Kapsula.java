package datakeeper;

import javax.swing.tree.DefaultMutableTreeNode;


/**
 * Klasa koja je wrapper za klasu Entity, nasledjuje 
 * DefaultMutableTreeNode
 * @author Marko Komlenovic
 *
 */
public class Kapsula extends DefaultMutableTreeNode {
		
		public Entity ent;
		public Kapsula(Entity n) {
			ent=n;
		}

	}
